package com.example.productos.service;

import com.example.productos.model.Producto;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

@Service
public class ProductoService {
    private final List<Producto> productos = new ArrayList<>();
    private final AtomicLong counter = new AtomicLong();

    // Constructor para agregar algunos productos de ejemplo
    public ProductoService() {
        productos.add(new Producto(counter.incrementAndGet(), "Laptop", "Laptop gaming", 10, 1200.0));
        productos.add(new Producto(counter.incrementAndGet(), "Smartphone", "Smartphone último modelo", 5, 800.0));
        productos.add(new Producto(counter.incrementAndGet(), "Teclado", "Teclado mecánico", 0, 150.0));
    }

    // Obtener todos los productos
    public List<Producto> getAllProductos() {
        return productos;
    }

    // Obtener un producto por ID
    public Producto getProductoById(Long id) {
        return productos.stream()
                .filter(producto -> producto.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    // Crear un nuevo producto
    public Producto createProducto(Producto producto) {
        // Validar que el precio sea mayor a 0 y la cantidad no sea negativa
        if (producto.getPrecioUnitario() <= 0) {
            throw new IllegalArgumentException("El precio debe ser mayor a 0");
        }
        if (producto.getCantidadStock() < 0) {
            throw new IllegalArgumentException("La cantidad no puede ser negativa");
        }

        // Asignar ID y añadir a la lista
        producto.setId(counter.incrementAndGet());
        productos.add(producto);
        return producto;
    }

    // Actualizar un producto existente
    public Producto updateProducto(Long id, Producto productoActualizado) {
        // Validar que el precio sea mayor a 0 y la cantidad no sea negativa
        if (productoActualizado.getPrecioUnitario() <= 0) {
            throw new IllegalArgumentException("El precio debe ser mayor a 0");
        }
        if (productoActualizado.getCantidadStock() < 0) {
            throw new IllegalArgumentException("La cantidad no puede ser negativa");
        }

        for (int i = 0; i < productos.size(); i++) {
            Producto producto = productos.get(i);
            if (producto.getId().equals(id)) {
                productoActualizado.setId(id);
                productos.set(i, productoActualizado);
                return productoActualizado;
            }
        }
        return null;
    }

    // Eliminar un producto
    public boolean deleteProducto(Long id) {
        return productos.removeIf(producto -> producto.getId().equals(id));
    }

    // Obtener estadísticas de los productos
    public Map<String, Object> getEstadisticas() {
        Map<String, Object> estadisticas = new HashMap<>();
        
        // Cantidad total de productos
        estadisticas.put("cantidadTotal", productos.size());
        
        // Promedio de precios
        double promedioPrecio = productos.stream()
                .mapToDouble(Producto::getPrecioUnitario)
                .average()
                .orElse(0.0);
        estadisticas.put("promedioPrecio", promedioPrecio);
        
        // Productos disponibles y agotados
        long disponibles = productos.stream().filter(p -> p.getEstado().equals("Disponible")).count();
        long agotados = productos.stream().filter(p -> p.getEstado().equals("Agotado")).count();
        
        estadisticas.put("disponibles", disponibles);
        estadisticas.put("agotados", agotados);
        
        return estadisticas;
    }
}
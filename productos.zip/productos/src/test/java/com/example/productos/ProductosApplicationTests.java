package com.example.productos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductosApplicationTests {

    @Test
    void contextLoads() {
        // Esta prueba simplemente verifica que el contexto de la aplicación puede cargarse
    }
}